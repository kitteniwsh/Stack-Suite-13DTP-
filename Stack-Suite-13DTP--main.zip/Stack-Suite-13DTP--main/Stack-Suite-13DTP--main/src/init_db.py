
from app import app
from models.extensions import Prime, Composite, db
from itertools import chain, combinations
from math import prod
with app.app_context():
    db.drop_all()
    db.create_all()


def primes(n):
    """https://stackoverflow.com/questions/2068372/fastest-way-to-list-all-primes-below-n """
    sieve = [True] * n
    for i in range(3,int(n**0.5)+1,2):
        if sieve[i]:
            sieve[i*i::2*i]=[False]*((n-i*i-1)//(2*i)+1)
    return [2] + [i for i in range(3,n,2) if sieve[i]]

def powerset(iterable):
    "powerset([1,2,3]) --> () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)"
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))


x = primes(11)


PTA = [Prime(value=i) for i in x]

PTAv = [i.value for i in PTA]

COMPv = []
all_combinations=list(set([ (prod(i), i) for i in powerset(PTAv)]))
print(all_combinations)
alll = list(set(powerset([i[0] for i in all_combinations])))
g = alll[5]
final = [ [prod(snp),   list(set(list(chain.from_iterable([all_combinations[[    i[0] for i in all_combinations  ].index(z)][1]   for z in snp])      )))] for snp in alll] 

print(len(final))

CTA = [Composite(value = i[0]) for i in final]
CTPA = [i[1] for i in final]
print(CTPA)
for i in CTA:
    for j in CTPA[CTA.index(i)]:
        i.Primes.append(Prime(value=j))

db.session.add_all[PTA]
db.session.add_all[CTA]
