## stAk suite
stAk suite is and internal tool used by the stAk CTF team it's written in flask and contains an array of various hacker tools and scripts. It's also used for organization of CTF events and management of the team.
